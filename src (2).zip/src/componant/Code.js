import React from 'react';
import book from "./book.jpg"
const Code = () => {
    return (
        <div>
            < img src='book'/>

        </div>
    );
};

export default Code;