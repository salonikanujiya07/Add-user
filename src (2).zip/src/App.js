import './App.css';
import AddUser from './componant/Adduser';
import Alluser from './componant/Alluser';
import EditUser from './componant/Edituser';
import NavBar from './componant/Navbar';
import { BrowserRouter , Routes , Route} from 'react-router-dom';



function App() {
  return (
    <BrowserRouter>
    <NavBar/>
    <Routes>
    < Route path='/add' element={<AddUser/>}/>
    <Route path='/all'  element={<Alluser/>}/>
    <Route path='edit/:id' element={<EditUser/>}/>
    </Routes>
    </BrowserRouter>
  );
}

export default App;
