import axios from 'axios';

// const usersUrl = 'http://localhost:3003/users';
const usersUrl = 'http://localhost:8000';

/* export const getUsers = async (id) => {
    id = id || '';
    return await axios.get(`${usersUrl}/${id}`);
} */
export const getUsers = async() =>{
    try{
        return await axios.get(`${usersUrl}/all`);
    } catch(error){
        console.log("here is one error when i try to call api", error);
    }
}

export const addUser = async (user) => {
    return await axios.post(`${usersUrl}/add`, user);
        
}

export const deleteUser = async (id) => {
   try{
    return await axios.delete(`${usersUrl}/${id}`);
   }
   catch(error){
    console.log('error while calling deleteUser API' , error)
   }
}

/* export const getUser = async (id, user) => {
    return await axios.put(`${usersUrl}/${id}`, user)

} */

export const getUser = async ( id)=>{
    try{
        return await axios.get(`${usersUrl}/${id}`);

    }catch(error){
        console.log("error while calling getUser api", error)
    }
}
export const editUser= async(User , id)=>{
    try{
        return await axios.post(`${usersUrl}/${id}`);
    }catch (error){
        console.log('Error while calling edituserapi', error);
    }
}