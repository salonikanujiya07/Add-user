 let mongoose = require('mongoose');
 //let autoIncrement = require('mongoose-auto-increment');

let userModel = new mongoose.Schema({
   name:{ type: String, required:true, unique:true},
    username:{ type:String, required:true},
    email:{ type:String , require:true},
    phone:{ type: Number, required:true}
 })
 //autoIncrement.initialize(mongo.connection);
 //userModel.plugin(autoIncrement.plugin, 'user');
 let postUser = mongoose.model('user', userModel);
 module.exports=postUser;
