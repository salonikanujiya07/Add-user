

let express= require('express');
 let mongoose=require('mongoose');
let dotenv =require ("dotenv");
let cors = require("cors");
//const { userSchema } =require ('./model/User.js');
const User   = require('./model/User.js');
const userModel = require('./model/User.js');
const bodyparser  = require('body-parser');
//const addUser = require ('./controlar/Controllar.js');
//const User = require('./model/User.js');

//const { addUser } = require('./controllar/controlar.js');
//const {  default: router } = require('./route/Route.js');

//let bodyparser = require("bodyparser");
const app = express();


dotenv.config();

// To handle HTTP POST requests in Express.js version 4 and above, 
// you need to install the middleware module called body-parser.
// body-parser extracts the entire body portion of an incoming request stream and exposes it on req.body.
app.use(bodyparser.json({extended: true }));
app.use(bodyparser.urlencoded({ extended: true }));
app.use(cors());

//app.use('/add', router);


const PORT = '8000';

app.listen(PORT, () => console.log(`Server is running successfully on PORT ${PORT}`));

mongoose.connect('mongodb://127.0.0.1:27017/organisation',
{
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then( console.log("Connected to MongoDB"))
.catch((error)=> { console.log(error);})


app.post('/add', async (req,res)=> {
    const user = req.body;
    const newUser =  new  User(user);
 try{
          await newUser.save();
         res.status(201).json(newUser);
         console.log("data added sucess");
     }
     catch(error)
     {
         res.status(409).json({ message: error.message});
         
     } 
  
 })
/*  export const addUser = async (request, response) => {
    const user = request.body;
    
    const newUser = new User(user);
    try{
        await newUser.save();
        response.status(201).json(newUser);
    } catch (error){
        response.status(409).json({ message: error.message});     
    }
} */

 app.get('/all', async (request, response)=> {
    try{
 
     let users = await userModel.find();
     response.json(users);
     }
     catch(error){
         //response.send(error);
         response.json({ message: error.message })
     }
 })
 

 app.get('/:id' , async (request , responce)=>{
   // console.log(request.params.id);
    try{
 
        let user = await userModel.findById(request.params.id);
        responce.json(user);
        }
        catch(error){
            //response.send(error);
            responce.json({ message: error.message })
        }
}) 
app.post('/:id', async (request , responce)=>{
    let user = request.body;

    const editUser = new User(user);
    try{
        await User.updateOne({_id: request.params.id}, editUser);
        responce.status(201).json(editUser);
    } 
    catch (error){
        responce.status(409).json({ message: error.message});     
    }
}
)
// deleting data of user from the database
app.delete('/:id',async (request, response) => {
    try{
        await User.deleteOne({_id: request.params.id});
        response.status(201).json("User deleted Successfully");
    } catch (error){
        response.status(409).json({ message: error.message});     
    }
})